-- DROP DATABASE szkola;
CREATE DATABASE IF NOT EXISTS szkola CHARACTER SET utf8 COLLATE utf8_unicode_ci;
 SET collation_connection = 'utf8_unicode_ci';


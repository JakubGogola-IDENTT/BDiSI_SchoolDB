SET AUTOCOMMIT=0;
-- Inserting values into table "pracownicy".
INSERT INTO pracownicy VALUES ('P00001','78081908963', 'Jan', 'Paweł', 'Wojtyła', '1978-08-19', 'Piłsudskiego 2/11', '55-200' ,'Oława',
								'00000000000000000000000001','jp@op.pl', 'nauczyciel', '666666666');
INSERT INTO pracownicy VALUES ('P00002','86022608965', 'Maciej', 'Paweł', 'Nowak', '1986-02-26', 'Leśna 2/3', '55-200' ,'Oława',
								'00000000000000000000000002','mn@op.pl', 'nauczyciel', '555555555');
INSERT INTO pracownicy VALUES ('P00003','53093008965', 'Paweł', 'Maciej', 'Krupski', '1953-09-30', 'Wyspiańskiego 2/3', '55-200' ,'Oława',
								'00000000000000000000000003','pkmlsr@op.pl', 'nauczyciel', '444444444');
                                
-- Inserting values into table 'klasy'.
INSERT INTO klasy VALUES ('GF4S','IA', 'P00001');
INSERT INTO klasy VALUES ('GR2R','IIA', 'P00002');
INSERT INTO klasy VALUES ('SF32','IIIA', 'P00003');

-- Inserting values into table 'przedmioty'.
INSERT INTO przedmioty VALUES ('Bazy danych', 'GF4S', 'P00001', 6);
INSERT INTO przedmioty VALUES ('Przyroda', 'GF4S', 'P00002', 6);
INSERT INTO przedmioty VALUES ('Analiza analityczna', 'SF32', 'P00003', 6);

-- Inserting values into table 'użytkownicy'.
INSERT INTO użytkownicy VALUES ('P00001', 'P00001', 'administrator');
INSERT INTO użytkownicy VALUES ('P00002', 'P00002', 'dyrektor');
INSERT INTO użytkownicy VALUES ('P00003', 'P00003', 'nauczyciel');

-- Inserting values into table 'wynagrodzenia'.
INSERT INTO wynagrodzenia VALUES ('P00001', '00000000000000000000000001', '2137.0');
INSERT INTO wynagrodzenia VALUES ('P00002', '00000000000000000000000002', '2137.0');
INSERT INTO wynagrodzenia VALUES ('P00003', '00000000000000000000000003', '2137.0');

                                
-- Inserting values into table 'uczniowie'.
INSERT INTO uczniowie VALUES ('U00001', '99010100000', 'Piotr', 'Robert', 'Kaloryfer', '1999-01-01', 'Paweł', 'Małgorzata', 
								'Szkolna 21/37', '55-200', 'Oława', '999999999', 'GF4S');
INSERT INTO uczniowie VALUES ('U00002', '99020200000', 'Marcin', 'Maciej', 'Zawadiaka', '1999-02-02', 'Maciej', 'Małgorzata', 
								'Wittiga 21/37', '55-200', 'Oława', '888888888', 'GR2R');
INSERT INTO uczniowie VALUES ('U00003', '99030300000', 'Matka', 'Jolanta', 'Gogoli', '1999-03-03', 'Paweł', 'Małgorzata', 
								'Szkolna 21/37', '55-200', 'Oława', '666666666', 'SF32');
                                
                                
SELECT * FROM uczniowie;

SELECT * FROM mysql.user;
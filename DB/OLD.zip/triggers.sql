DROP TRIGGER IF EXISTS beforeDeleteOnPracownicy;
DELIMITER $$
CREATE TRIGGER beforeDeleteOnPracownicy BEFORE DELETE ON pracownicy FOR EACH ROW
BEGIN
	-- Removing record from table 'wynagrodzenia'.
    DELETE FROM wynagrodzenia 
    WHERE Kod_pracownika = OLD.Kod;
    
    -- Updating table 'przedmioty'.
    UPDATE przedmioty
    SET Kod_nauczyciela = NULL
    WHERE Kod_nauczyciela = OLD.Kod;
    
    -- Deleting usuer from tabler 'użytkownicy'.
    DELETE FROM użytkownicy
    WHERE Kod_pracownika = OLD.Kod;
    
    -- Updating table 'klasy'.
    UPDATE klasy
    SET Wychowawca = NULL
    WHERE Wychowawca = OLD.Kod;
    
    
END $$
DELIMITER ;

DROP TRIGGER IF EXISTS afterDeleteOnKlasy;
DELIMITER $$
CREATE TRIGGER afterDeleteOnKlasy AFTER DELETE ON klasy FOR EACH ROW
BEGIN
	DELETE FROM przedmioty
    WHERE Kod_klasy = OLD.Kod;
    
END $$
DELIMITER ;



DROP TRIGGER IF EXISTS afterUpdateOnUżytkownicy;
DELIMITER $$
CREATE TRIGGER afterUpdateOnUżytkowcniy AFTER UPDATE ON Użytkownicy FOR EACH ROW
BEGIN
	IF (NEW.LOGIN <> OLD.LOGIN) THEN
		SET @query = CONCAT("ALTER USER '",OLD.LOGIN,"'@'localhost' WITH NAME='", NEW.LOGIN ,"';");
	ELSEIF (NEW.Uprawnienia <> OLD.Uprawnienia) THEN
		IF (NEW.Uprawnienia = 'dyrektor') THEN
		SET @query = CONCAT("GRANT GRANT, EXECUTE ON *.* TO '", usrname ,"'@'localhost'; FLUSH PRIVILEGES;");
		ELSEIF (NEW.Uprawnienia = 'administrator') THEN
		SET @query = CONCAT("GRANT ALL PRIVILIDGES ON *.* TO '", usrname ,"'@'localhost'; FLUSH PRIVILEGES;");
		ELSEIF (NEW.Uprawnienia = 'sekretaria' OR NEW.Uprawnienia='nauczyciel') THEN
		SET @query = CONCAT("GRANT EXECUTE ON *.* TO '", usrname ,"'@'localhost'; FLUSH PRIVILEGES;");
		END IF;
	END IF;
	PREPARE stmt FROM @query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
END $$
DELIMITER ;

-- TODO - adter delete delete user 

SELECT * FROM przedmioty;
